let meuBotao = document.querySelector('button');
let dataForm = document.querySelector('input[type="date"]');
let meuCabecalho = document.querySelector('h1');


function dataTela() {
  console.log(dataForm);
  // meuCabecalho.innerHTML = dataFormatada;
}

// meuBotao.onclick = function () { dataTela(); }