package Model.DAO;

import DatabaseConnection.Conexao;
import Model.Bean.Membros;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MembrosDAO {

	// m�todo respons�vel por preparar os dados a serem inseridos no banco de dados.
	// A inser��o � feita atrav�s do nome do membro
	public void inserirDados(Membros membro) throws SQLException, ClassNotFoundException { // O retorno � vazio e recebe
																							// um objeto do tipo
																							// Membros.
		Connection con = Conexao.conector(); // invoca a conex�o com o banco
		PreparedStatement prepStmt = null; // objeto que representa um apontamento de SQL pr�-compilado.
		try {
			prepStmt = con.prepareStatement("INSERT INTO membros VALUES (DEFAULT, ?)"); // Defini��o do SQL a ser
																						// utilizado no banco de dados.
			prepStmt.setString(1, membro.getNome()); // trata a String a ser encaminhada para o banco de dados.
			prepStmt.executeUpdate(); // metodo respons�vel por fazer a altera��o no banco de dados (No caso, uma
										// inser��o).
		} catch (SQLException ex) { // Tratamento das exce��o
			System.out.println(ex);
		} finally { // finaliza��o dos objetos relacionados ao banco de dados
			if (prepStmt != null)
				try {
					prepStmt.close();
				} catch (SQLException ignore) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ignore) {
				}
		}
	}

	// m�todo respons�vel por excluir dados do banco. A exclus�o � feita pelo ID.
	public void deletarDados(Membros m) throws SQLException, ClassNotFoundException { // O retorno � vazio e recebe um
																						// objeto do tipo Membros.
		Connection con = Conexao.conector(); // invoca a conex�o com o banco
		PreparedStatement stmt = null;// trata a String a ser encaminhada para o banco de dados.
		try {
			stmt = con.prepareStatement("DELETE FROM membros WHERE id = ?"); // Defini��o do SQL a ser utilizado no
																				// banco de dados.
			stmt.setInt(1, m.getId()); // o primeiro par�metro se refere � ordem de interroga��es da instru��o SQL
										// anterior, iniciando de 1.
			stmt.executeUpdate(); // metodo respons�vel por fazer a altera��o no banco de dados (No caso, uma
									// remo��o).
		} catch (SQLException ex) { // Tratamento das exce��o
			System.out.println(ex);
		} finally {// finaliza��o dos objetos relacionados ao banco de dados
			if (stmt != null)
				try {
					stmt.close();
				} catch (SQLException ignore) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ignore) {
				}
		}
	}

	// m�todo respons�vel por alterar os dados do banco. A altera��o � feita pelo
	// nome e pelo ID, respectivamente.
	public void atualizarDados(Membros m) throws SQLException, ClassNotFoundException { // O retorno � vazio e recebe um
																						// objeto do tipo Membros.
		Connection con = Conexao.conector(); // invoca a conex�o com o banco
		PreparedStatement stmt = null;// trata a String a ser encaminhada para o banco de dados.
		try {
			stmt = con.prepareStatement("UPDATE membros SET nome = ? WHERE id = ?"); // Defini��o do SQL a ser utilizado
																						// no banco de dados.
			stmt.setString(1, m.getNome());// o par�metro 1 se refere � primeira interroga��es da instru��o SQL
											// anterior.
			stmt.setInt(2, m.getId());// o par�metro 2 se refere � primeira interroga��es da instru��o SQL anterior.
			stmt.executeUpdate(); // metodo respons�vel por fazer a altera��o no banco de dados (No caso, uma
									// remo��o).
		} catch (SQLException ex) { // Tratamento das exce��o
			System.out.println(ex);
		} finally {
			if (stmt != null)
				try {
					stmt.close();
				} catch (SQLException ignore) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ignore) {
				}
		}
	}

	// m�todo respons�vel por listar todos os membros do banco de dados.
	public List<Membros> listarDados() throws SQLException, ClassNotFoundException { // Retorna uma lista com todos os
																						// Membros cadastrados no banco.
		Connection con = Conexao.conector(); // invoca a conex�o com o banco
		PreparedStatement stmt = null;// trata a String a ser encaminhada para o banco de dados.
		ResultSet rs = null; // Objeto que armazena o resultado de uma busca em uma estrutura de dados que
								// pode ser percorrida. No caso foi utilizada uma lista.
		List<Membros> listaDeMembros = new ArrayList<>(); // Instancia uma nova lista encadeada para receber os valores
															// do banco.
		try {
			stmt = con.prepareStatement("SELECT * FROM membros");// Defini��o do SQL a ser utilizado no banco de dados.
			rs = stmt.executeQuery(); // Executa o comando SQL
			while (rs.next()) { // percorre todos os valores das linhas da tabela do banco de dados, faz isso
								// enquanto houve valores.
				Membros membroObj = new Membros(); // instancia um objeto da classe Membros.
				membroObj.setId(rs.getInt("id")); // busca o valor de ID retornado da linha da tabela.
				membroObj.setNome(rs.getString("nome")); // busca o nome do membro retornado da linha da tabela.
				listaDeMembros.add(membroObj); // Adiciona o objeto com o ID e Nome na lista criada.
			}
		} catch (SQLException ex) { // Tratamento das exce��o
			System.out.println(ex);
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ignore) {
				}
			if (stmt != null)
				try {
					stmt.close();
				} catch (SQLException ignore) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ignore) {
				}
		}
		return listaDeMembros; // Retorna a lista preenchida.
	}

}
