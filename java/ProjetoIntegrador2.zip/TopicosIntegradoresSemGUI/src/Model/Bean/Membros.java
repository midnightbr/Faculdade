package Model.Bean;

//Classe de Membros, s� possui 2 par�metros, ID e NOME e os getters e setters. 
public class Membros {
	private Integer id;
	private String nome;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
