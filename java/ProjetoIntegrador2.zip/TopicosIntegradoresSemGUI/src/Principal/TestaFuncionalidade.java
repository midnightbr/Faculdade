package Principal;

import java.sql.SQLException;

import Model.Bean.Membros;
import Model.DAO.MembrosDAO;

public class TestaFuncionalidade {

	// executa a inser��o.
	public void testaInsercao() throws ClassNotFoundException {
		Membros membrosObj = new Membros(); // Instancia o objeto da classe Membros para herdar todos os atributos e
											// m�todos.
		MembrosDAO dao = new MembrosDAO();// Instancia o objeto da classe MembrosDAO para herdar todos os atributos e
											// m�todos.
		membrosObj.setNome("Alex Sander");// String a ser inserida no banco de dados.
		try {
			dao.inserirDados(membrosObj); // onde de fato o membro � inserido.
			System.out.println("Dado inserido no banco com sucesso");
		} catch (SQLException e) {
			System.out.println("Problemas na conexao com o banco de dados." + e);
		}
	}

	public void testaExclusao() throws ClassNotFoundException {
		Membros membrosObj = new Membros();// Instancia o objeto da classe Membros para herdar todos os atributos e
											// m�todos.
		MembrosDAO dao = new MembrosDAO();// Instancia o objeto da classe MembrosDAO para herdar todos os atributos e
											// m�todos.
		membrosObj.setId(5); // configura��o da exclus�o, ela � feita pelo ID do membro.
		try {
			dao.deletarDados(membrosObj); // onde de fato o membro � exclu�do.
			System.out.println("Dado removido do banco com sucesso");
		} catch (SQLException e) {
			System.out.println("Problemas na conexao com o banco de dados." + e);
		}
	}

	public void testaAtualizacao() throws ClassNotFoundException {
		Membros membrosObj = new Membros();// Instancia o objeto da classe Membros para herdar todos os atributos e
											// m�todos.
		MembrosDAO dao = new MembrosDAO();// Instancia o objeto da classe MembrosDAO para herdar todos os atributos e
											// m�todos.
		membrosObj.setNome("Eduardo");// configura o nome a ser alterado.
		membrosObj.setId(12); // altera o nome que estava no ID mencionado pelo valor da String da linha
								// anterior.
		try {
			dao.atualizarDados(membrosObj); // executa o m�todo de atualiza��o da tabela do banco.
			System.out.println("Dado atualizado no banco com sucesso");
		} catch (SQLException e) {
			System.out.println("Problemas na conexao com o banco de dados." + e);
		}
	}

	public void testSelecao() throws ClassNotFoundException {
		MembrosDAO dao = new MembrosDAO();// Instancia o objeto da classe MembrosDAO para herdar todos os atributos e
											// m�todos.
		try {
			for (Membros membrosObj : dao.listarDados()) { // for aprimorado. Utilizado para percorrer todos os dados da
															// lista de membros que foi retornada pelo banco. Sua
															// vantagem � que n�o precisa mencionar a condi��o de
															// parada.
				System.out.println("| ID: " + membrosObj.getId() + " | Nome: " + membrosObj.getNome()); // imprime os
																										// valores da
																										// lista de
																										// membros.
			}
		} catch (SQLException e) { // tratamento de exce��o.
			System.out.println("Problemas na conexao com o banco de dados." + e);
		}
	}

	// m�todo principal. Aqui voc� pode desconmentar os m�todos que deseja testar.
	public static void main(String[] args) throws ClassNotFoundException {

		TestaFuncionalidade testeFunc = new TestaFuncionalidade();

		// descomente a linha abaixo para inserir membros, mas altere os valores no
		// respectivo m�todo acima.
		// testeFunc.testaInsercao();

		// descomente a linha abaixo para deletar membros, mas altere os valores no
		// respectivo m�todo acima.
		// testeFunc.testaExclusao();

		// descomente a linha abaixo para atualizar os membros, mas altere os valores no
		// respectivo m�todo acima.
		// testeFunc.testaAtualizacao();

		// descomente a linha abaixo para listar os membros
		testeFunc.testSelecao();
	}

}
