/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseConnection;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {

	public static Connection conector() {
		java.sql.Connection conexao = null;
		String driver = "com.mysql.cj.jdbc.Driver"; // String padr�o que informa qual o Driver que est� sendo utilizado,
													// no caso o JDBC do MYSQL.
		String url = "jdbc:mysql://localhost:3306/pet?useTimezone=true&serverTimezone=UTC"; // caminho de conex�o com
																							// banco. Obs: "pet" � o
																							// nome do banco do exemplo,
																							// deve ser alterado para o
																							// nome do seu banco
		String usuario = "root"; // coloque aqui o seu usu�rio do MYSQL.
		String senha = "P@ssw0rd"; // coloque aqui a senha do banco que voc� criou.
		try {
			Class.forName(driver); // Carrega e inicia o driver passado por par�metro.
			conexao = DriverManager.getConnection(url, usuario, senha); // Estabelece a conex�o a partir do driver
																		// adicionado nas bibliotecas.
			if (conexao != null) // testa o estado da conex�o.
				System.out.println("Conex�o aberta com sucesso!");

			return conexao;
		} catch (Exception ex) { // Tratamento de exce��o
			System.out.println(ex);
			System.out.println("N�o foi poss�vel realizar a conex�o com o banco!");
			return null;
		}
	}
}
